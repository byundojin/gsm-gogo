function VoteItem() {
  <>
    <VoteBox />
  </>;
}

export default VoteItem;
