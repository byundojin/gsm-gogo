function EventPage() {
  return (
    <>
      <h1>EventPage</h1>
    </>
  );
}

export default EventPage;
