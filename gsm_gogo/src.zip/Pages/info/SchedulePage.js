function SchedulePage() {
  return (
    <>
      <h1>SchedulePage</h1>
    </>
  );
}

export default SchedulePage;
