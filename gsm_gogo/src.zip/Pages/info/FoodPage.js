function FoodPage() {
  return (
    <>
      <h1>FoodPage</h1>
    </>
  );
}

export default FoodPage;
